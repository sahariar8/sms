   @include('frontend.common.header')
    @yield('main')
    @yield('info')
   @include('frontend.common.footer')