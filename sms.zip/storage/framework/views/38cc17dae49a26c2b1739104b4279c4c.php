
<?php $__env->startSection('info'); ?>
    <div class="container">
        <h1  class="text-center text-primary" style="margin-top: 200px;font-family:sans-serif; font-weight:800;font-size:40px">Student Personal Information</h1>
        <div class="row info">
            
            <div class=" col-md-6 col-sm-12" style="margin-top: 15px">
                    <table class="table table-bordered text-center" style="border-radious:8px">

                        <tr>
                            <th class="text-center text-primary">Name</th>
                            <td><?php echo e($student->name); ?></td>
                            <td rowspan="5"> <img src="<?php echo e(asset('/')); ?><?php echo e($student->img); ?>" alt="" style="height: 150px; width:150px"></td>
                        </tr>
                        
                        <tr>
                            <th class="text-center text-primary">City</th>
                            <td><?php echo e($student->city); ?></td>
                        </tr>
                        <tr>
                           
                            <th class="text-center text-primary">Contact</th>
                            <td><?php echo e($student->contact); ?></td>
                        </tr>
                        <tr>
                            <th class="text-center text-primary">Roll</th>
                            <td><?php echo e($student->roll); ?></td>
                        </tr>
                        <tr>
                            <th class="text-center text-primary">class</th>
                            <td><?php echo e($student->class); ?></td>
                        </tr>
                       
                       
                       

                    </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master.fmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sms\resources\views/frontend/pages/studentinfo.blade.php ENDPATH**/ ?>