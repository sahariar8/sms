
<?php $__env->startSection('student.add'); ?>
<div class="container">
    <h3 class="text-center m-5" style="font-family:Sans-serif; font-weight:800;font-size:40px; color:#428bca;">Student Information Update Form</h3>
    <h4 class="text-center text-success"><?php echo e(Session::get('msg')); ?></h4>
    <div class="row">
        <div class="col-md-6 col-sm-12" style="margin: auto;">
            <form  action="<?php echo e(route('student.update',$student->id)); ?>" method="POST" enctype="multipart/form-data" class="p-5 border border rounded">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="name"><b>Name:</b></label>
                  <input type="text" class="form-control mb-3" name="name" value="<?php echo e($student->name); ?>">
                </div>
                <div class="form-group">
                  <label for="roll"><b>Roll:</b></label>
                  <input type="text" class="form-control mb-3"placeholder="Enter roll ( 6 digit )"  pattern="[0-9]{6}" name="roll" value="<?php echo e($student->roll); ?>">
                </div>
                <div class="form-group">
                  <label for="class"><b>Class:</b></label>
                  
                  <select name="class" id="class" class="form-control" >
                        <option value="<?php echo e($student->class); ?>"<?php echo e($student->class == 1 ? 'selected' : ''); ?>>Class-1</option>
                        <option value="<?php echo e($student->class); ?>"<?php echo e($student->class == 2 ? 'selected' : ''); ?>>Class-2</option>
                        <option value="<?php echo e($student->class); ?>"<?php echo e($student->class == 3 ? 'selected' : ''); ?>>Class-3</option>
                        <option value="<?php echo e($student->class); ?>"<?php echo e($student->class == 4 ? 'selected' : ''); ?>>Class-4</option>
                        <option value="<?php echo e($student->class); ?>"<?php echo e($student->class == 5 ? 'selected' : ''); ?>>Class-5</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="city"><b>City:</b></label>
                  <input type="text" class="form-control mb-3" name="city" value="<?php echo e($student->city); ?>">
                </div>
                <div class="form-group">
                  <label for="contact"><b>Contact:</b></label>
                  <input type="text" class="form-control mb-3"placeholder="Enter Mobile Number"  pattern="[0-9]{11}" name="contact" value="<?php echo e($student->contact); ?>">
                </div>
                <div class="form-group">
                  <label for="img"><b>Image:</b></label>
                  <img src="<?php echo e(asset('/')); ?><?php echo e($student->img); ?>" alt="" style="height: 50px; width:50px">
                </div>
                <div class="form-group">
                  <label for="img"><b>Image:</b></label>
                  <input type="file" class="form-control mb-3" name="img">
                </div>
                <button type="submit" class="btn text-light" style="background-color: #428bca;">Submit</button>
              </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.bmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sms\resources\views/backend/pages/edit_student.blade.php ENDPATH**/ ?>