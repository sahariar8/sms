
<?php $__env->startSection('all.students'); ?>
<div class="container">
    <h3 class="text-center m-5" style="font-family:Sans-serif; font-weight:800;font-size:40px; color:#428bca;">All Students Details</h3>
    <h4 class="text-center text-success"><?php echo e(Session::get('msg')); ?></h4>
    <div class="row">
        <div class="col-md-8 col-sm-12" style="margin: auto;">
            <table class="table table-bordered text-center">
                <tr>
                    <th>#Id</th>
                    <th>Name</th>
                    <th>Class</th>
                    <th>Roll</th>
                    <th>City</th>
                    <th>Contact</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($s->id); ?></td>
                    <td><?php echo e($s->name); ?></td>
                    <td><?php echo e($s->class); ?></td>
                    <td><?php echo e($s->roll); ?></td>
                    <td><?php echo e($s->city); ?></td>
                    <td><?php echo e($s->contact); ?></td>
                    <td><img src="<?php echo e(asset('/')); ?><?php echo e($s->img); ?>" alt="" style="height: 50px; width:50px"></td>
                    <td>
                        <a href="<?php echo e(route('student.edit',$s->id)); ?>" class="btn btn-warning">Edit</a>
                        <a href="<?php echo e(route('student.destroy',$s->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you Sure to delete this Student?')">Delete</a>
                    </td>
                </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.bmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sms\resources\views/backend/pages/all_students.blade.php ENDPATH**/ ?>